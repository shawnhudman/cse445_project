using System;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Application["StartTime"] != null)
            litStartTime.Text = "Application started at: " +
                                ((DateTime)Application["StartTime"]).ToString("F");
    }

    protected void btnHash_Click(object sender, EventArgs e)
    {
        lblHashResult.Text = HashUtility.HashString(txtInput.Text);
    }

    protected void btnCount_Click(object sender, EventArgs e)
    {
        lblCountResult.Text = TextStats.WordCount(txtInput.Text).ToString();
    }
}
