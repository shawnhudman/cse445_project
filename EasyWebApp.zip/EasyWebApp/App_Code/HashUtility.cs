using System;
using System.Security.Cryptography;
using System.Text;
//Hash: provides sha256 hashing of input strings
public static class HashUtility
{
    public static string HashString(string input) //hash the string
    {
        if (input == null) return null;
        using (var sha = SHA256.Create())
        {
            byte[] bytes = sha.ComputeHash(Encoding.UTF8.GetBytes(input));
            return BitConverter.ToString(bytes).Replace("-", "").ToLowerInvariant(); //use Bitconverter
        }
    }
}
